# Pilot study protocol: fatigue monitoring prototype

**Aim.** Check on real volunteers whether the fused fatigue risk from the camera and wristband agrees with how tired they say they are, and how quickly an alert follows.

**Volunteers.** 8 to 12 adult students or staff, each with written consent (`consent_form.md`). Anyone may stop at any time. No medical conditions are assessed or recorded, and the system is not a medical device.

**Task.** 30 to 45 minutes of repetitive physical work at a table (for example sorting and stacking boxes, or assembling parts), seated or standing, wearing the wristband, facing the camera. Include one 2 minute period with safety glasses on, to test the camera-blind case.

**Ground truth.** Every 5 minutes the volunteer states a Borg RPE rating (6 to 20; see `log_sheet.csv`) and an observer notes the clock time. A rating of 13 or more ("somewhat hard" and above) counts as fatigued.

**Procedure.**
1. Explain the study, collect consent, fit the wristband, check the camera view.
2. Start `edge_runner.py` with `--log P01.jsonl` (one log per volunteer), start the work task, and note the clock time.
3. At each 5 minute mark the observer records the rating in the log sheet.
4. At the end, stop the program and thank the volunteer. Keep files by participant code (P01, P02, ...), never by name.

**Data protection.** Only scores are stored, not video. Keep consent forms apart from the logs. Delete raw files at the end of the project period.

**Analysis.** `python3 pilot/analyze_pilot.py --logs pilot/logs --ratings pilot/ratings.csv` reports, per volunteer and overall: agreement with the Borg threshold, missed-fatigue rate, false-alarm rate, time from first rating of 13 or more to the first alert, and how often the camera was blind.

**Limits to state in the report.** Small sample, one task, self-report as ground truth, models first trained on simulated data.
