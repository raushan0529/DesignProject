"""Train the wearable model (and a leave-one-subject-out check) on a real wearable fatigue dataset such as
Mohapatra et al. (https://zenodo.org/records/12788571).

The column names of that dataset must be confirmed once it is downloaded, so they are command-line options.
Input: one CSV per subject OR one CSV with a subject column. Needed per row: time in seconds, heart rate,
SpO2, accelerometer axes, and a fatigue label (binary, or a rating that --threshold turns into binary).

  python3 kit/train_wearable_real.py --data /path/to/csvs --time-col t --hr-col hr --spo2-col spo2 \
      --acc-cols ax,ay,az --label-col borg --threshold 13 --subject-col subject
Evaluation is leave-one-subject-out (GroupKFold), so the score is on people never seen in training.
"""
import argparse, glob, json, os, pickle, sys
import numpy as np, pandas as pd
import xgboost as xgb
from sklearn.model_selection import GroupKFold
from sklearn.metrics import accuracy_score, recall_score, precision_score, f1_score, roc_auc_score
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
import wearable

WIN, STEP = 10, 5


def windows(df, a):
    t = df[a.time_col].to_numpy(float); t = t - t[0]
    T = int(t[-1])
    g1 = np.arange(T); g50 = np.arange(T * 50) / 50.0
    hr = np.interp(g1, t, df[a.hr_col].to_numpy(float)); sp = np.interp(g1, t, df[a.spo2_col].to_numpy(float))
    ax = np.stack([np.interp(g50, t, df[c].to_numpy(float)) for c in a.acc_cols.split(",")], 1)
    mag = np.linalg.norm(ax, axis=1); mag = mag - mag.mean()
    lab = np.interp(g1, t, df[a.label_col].to_numpy(float))
    X, y = [], []
    for s in range(0, T - WIN + 1, STEP):
        X.append(wearable.wearable_features(hr[s:s + WIN], sp[s:s + WIN], mag[s * 50:(s + WIN) * 50]))
        y.append(int(lab[s:s + WIN].mean() >= a.threshold))
    return np.array(X), np.array(y)


def main():
    ap = argparse.ArgumentParser()
    for k in ("data", "time-col", "hr-col", "spo2-col", "acc-cols", "label-col"):
        ap.add_argument("--" + k, required=True)
    ap.add_argument("--subject-col"); ap.add_argument("--threshold", type=float, default=0.5); ap.add_argument("--out", default="artifacts_real")
    a = ap.parse_args(); a.time_col, a.hr_col, a.spo2_col, a.acc_cols, a.label_col = a.time_col, a.hr_col, a.spo2_col, a.acc_cols, a.label_col
    files = sorted(glob.glob(os.path.join(a.data, "*.csv"))) if os.path.isdir(a.data) else [a.data]
    X, y, G = [], [], []
    for i, f in enumerate(files):
        df = pd.read_csv(f)
        parts = [(i, df)] if not a.subject_col else [(f"{i}-{k}", d) for k, d in df.groupby(a.subject_col)]
        for sid, d in parts:
            xs, ys = windows(d.reset_index(drop=True), a)
            X += list(xs); y += list(ys); G += [hash(sid) % 10**9] * len(ys)
    X, y, G = np.array(X), np.array(y), np.array(G)
    print(f"{len(X)} windows, {len(set(G))} subjects, fatigued share {y.mean():.2f}")
    gbm = lambda: xgb.XGBClassifier(n_estimators=160, max_depth=3, learning_rate=.08, subsample=.9, colsample_bytree=.9, eval_metric="logloss", n_jobs=2)
    oof = np.zeros(len(y))
    for tr, te in GroupKFold(min(5, len(set(G)))).split(X, y, G):
        oof[te] = gbm().fit(X[tr], y[tr]).predict_proba(X[te])[:, 1]
    yh = (oof >= .5).astype(int)
    res = dict(windows=len(y), subjects=int(len(set(G))), accuracy=accuracy_score(y, yh), recall=recall_score(y, yh), precision=precision_score(y, yh, zero_division=0),
               f1=f1_score(y, yh), auc=roc_auc_score(y, oof) if len(set(y)) > 1 else None)
    res = {k: (None if v is None else int(v) if k in ("windows", "subjects") else round(float(v), 4)) for k, v in res.items()}
    os.makedirs(a.out, exist_ok=True)
    pickle.dump(gbm().fit(X, y), open(f"{a.out}/wearable_model.pkl", "wb"))
    json.dump(res, open(f"{a.out}/wearable_metrics.json", "w"), indent=1); print(res)


if __name__ == "__main__":
    main()
