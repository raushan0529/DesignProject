# Volunteer consent form

Project: Intelligent Industrial Worker Safety and Fatigue Monitoring System, E1CSA313 Design Project-I, Alliance School of Advanced Computing.

I understand that:
- I will do 30 to 45 minutes of light physical work while wearing a wristband (heart rate, blood oxygen, movement) and facing a camera.
- The system keeps only numeric scores. Video is processed on the device and is not saved.
- I will be asked how tired I feel every 5 minutes.
- My data is filed under a code (for example P01), not my name, and is used only for this course project.
- This is a student prototype, not a medical device. It does not diagnose anything.
- I can stop at any time without giving a reason.

Participant code: ________   Name: ______________________   Signature: ______________   Date: ________
Team member present: ______________________
